# Trabalho de Grafos
## Parte 1:
- [] a) Subgrafo induzido por um conjunto de vértices (parâmetro de entrada do método/função)
- [] b) Caminho mínimo entre dois vértices (parâmetros) usando algoritmo de Djkstra;
- [] c) Caminho mínimo entre dois vértices (parâmetros) usando algoritmo de Floyd;
- [] d) Árvore Geradora Mínima usando o algoritmo de Prim;
- [] e) Árvore Geradora Mínima usando o algoritmo de Kruskal;
- [] f) Busca em largura a partir de um dado nó (parâmetro);
- [] g) Ordenação topológica de um DAG (Grafo Acíclico Direcionado);
- [ ] Salvar grafo para .dot
## Parte 2:
- [] Algorítmo Guloso
- [] Algorítmo Guloso Randomizado
- [] Algoritmo Guloso Randomizado Reativo
- [] Kruskal Randomizado


### TO FIX:
- [ ] Node::RemoveEdge


## Como Compilar?
Utilizando o arquivo Makefile com os comando:
Make clean - exclui todos os arquivos .o e o arquivo ./grafo.exe 
Make all - cria o arquivo grafo.exe e todos os arquivos .o


## Como rodar?
./grafo.exe input.txt output.txt 0 0 0